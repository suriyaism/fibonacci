"""
    Module intended to calculate the fibonacci series
    and find all combinations of fibonacci number that add up to
    that particular number.
"""

import datetime
from itertools import combinations_with_replacement
import utilities.utils as common_utils
import utilities.response_builder as response_builder

logger = common_utils.get_logger()


class Fibonacci:
    # Guides the entire solution with validators and response output
    def performer(self, n):
        try:
            logger.info(n)
            # if input is not valid, throw error and return error response
            self.is_input_valid(n)
            # else Calculate Factorial
            response_data = self.get_fibonacci_response_data(n)
            response = response_builder.get_success_response(
                status_code=200,
                data=response_data
            )
        except ValueError as err:
            logger.error(err)
            response = response_builder.get_error_response(status_code=400)
        except RecursionError as err:
            logger.error(err)
            response = response_builder.get_error_response(status_code=422)
        except (KeyError, IOError, TimeoutError, Exception) as err:
            logger.error(err)
            response = response_builder.get_error_response()
        return response

    # Validates if the input is correct and can also be done by raising an Error
    def is_input_valid(self, input_value=None):
        if not str(input_value).isdigit() or not str(input_value).isdecimal() or int(input_value) <= 2:
            raise ValueError()
        elif int(input_value) > 30:
            raise RecursionError()
        else:
            return True

    # Prepares response series along with time consumed
    def get_fibonacci_response_data(self, n):
        start = datetime.datetime.utcnow().timestamp()
        n = int(n)
        fibonacci_seq = self.calculate_fibonacci(n)
        fibonacci_combinations = self.combinations(n, fibonacci_seq)
        end = datetime.datetime.utcnow().timestamp()

        # converting the difference to milliseconds
        time_taken = (end - start) * 1000

        response_data = {
            "n": n,
            "fibonacci": fibonacci_combinations,
            "timeTakenMillis": round(time_taken, 3)
        }
        return response_data

    # Prepares response along with time constraint values
    @staticmethod
    def calculate_fibonacci(n):
        x, y = 1, 1
        z = 1
        fibonacci = []

        while z <= n:
            z = x + y
            x, y = y, z
            if z <= n:
                fibonacci.append(z)
        return fibonacci

    # Generates all combinations from the fibonacci sequence that add upto to sum of n
    @staticmethod
    def combinations(n, fibonacci_seq):
        fib_array, combinations = [], []
        for i in range(0, fibonacci_seq[-1]):
            product = list(combinations_with_replacement(fibonacci_seq, i))
            fib_array += product

        for item in fib_array:
            if sum(item) == n:
                combinations.append(list(item))
        return sorted(combinations)


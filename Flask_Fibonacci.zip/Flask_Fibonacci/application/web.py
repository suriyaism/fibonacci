from flask import Flask
from application.fibonacci import Fibonacci


application = Flask(__name__)

@application.route("/fib/<int:number>", methods=["GET"])
def fib(number):
    fib_sec_calc = Fibonacci()
    return fib_sec_calc.performer(n=number)


if __name__ == "__main__":
    application.run()
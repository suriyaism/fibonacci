import os
import sys
import markdown
import datetime, json
from flask import Flask, Markup, render_template
from src.app.fibonacci import Fibonacci
from flask_caching import Cache
from healthcheck import HealthCheck


application = Flask(__name__)
cache = Cache()

cache.init_app(application, config={"CACHE_TYPE": "simple"})

HOST = "127.0.0.1"
PORT = "5000"


@application.route("/", methods=["GET"])
def index():
    # Open the README file
    print(str(os.path.dirname(application)))
    #with open(os.path.dirname(application) + '/README.md', 'r') as markdown_file:
        # Read the markdown contents
        #content = markdown_file.read()

        # Convert the markdown to HTML and then treat it as actual HTML so it's not escaped
        #html = Markup(markdown.markdown(content, extensions=['markdown.extensions.fenced_code']))

    #return render_template(os.path.dirname(application.root_path) + '/src/app/index.html', content=html)

    return {"message": "success",
            "response": "Welcome to the homepage, try with '/fib/<number>' or '/health'"}


@application.route("/fib/<number>", methods=["GET"])
def fib(number):
    start = datetime.datetime.utcnow().timestamp()
    fib_sec_calc = Fibonacci()
    output = cache.get(number)
    if output is None:
        output = fib_sec_calc.performer(n=number)
        cache.set(number, output)
    end = datetime.datetime.utcnow().timestamp()
    time_taken = (end - start) * 1000  # converting the difference to milliseconds
    return json.dumps({"output": output, "timeTakenMillis": str(round(time_taken, 3))})


@application.route("/health", methods=["GET"])
def health():
    health_check = HealthCheck()
    health_check.add_check()


if __name__ == "__main__":
    application.run(host=HOST, port=PORT, threaded=True)

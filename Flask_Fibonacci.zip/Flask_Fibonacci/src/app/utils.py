"""
This module is intended to be used to handle
the logs
"""
import logging

logging.basicConfig(filename='Flask_Fibonacci.log')


def get_logger():
    log = logging.getLogger()
    log.setLevel(logging.DEBUG)
    return log

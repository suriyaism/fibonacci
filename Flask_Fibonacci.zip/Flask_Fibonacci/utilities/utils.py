"""
This module is intended to be used to handle
the logs
"""
import logging


def get_logger(logger_name='Flask_Fibonacci'):
    logging.basicConfig(filename='Flask_Fibonacci.log')
    log = logging.getLogger(logger_name)
    log.setLevel(logging.DEBUG)
    return log
